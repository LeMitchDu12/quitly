import React, { useMemo, useState } from "react";
import { Text, View, StyleSheet, Pressable, Alert, Platform } from "react-native";
import Screen from "../components/Screen";
import { useTranslation } from "react-i18next";
import { theme } from "../theme";
import i18n from "../i18n";

import { StorageKeys } from "../storage/keys";
import { getNumber, getString, setNumber, setString, getBool, setBool } from "../storage/mmkv";

import {
  requestNotifPermissions,
  scheduleDailyMotivation,
  cancelAllNotifications,
} from "../notifications";

function Chip({
  title,
  onPress,
  tone = "default",
}: {
  title: string;
  onPress: () => void;
  tone?: "default" | "primary" | "danger";
}) {
  const borderColor =
    tone === "primary" ? theme.colors.primary : tone === "danger" ? theme.colors.danger : theme.colors.outline;

  const textColor =
    tone === "primary" ? theme.colors.primary : tone === "danger" ? theme.colors.danger : theme.colors.textPrimary;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        { borderColor },
        pressed && { opacity: 0.9, transform: [{ scale: 0.99 }] },
      ]}
    >
      <Text style={[styles.chipText, { color: textColor }]}>{title}</Text>
    </Pressable>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

export default function SettingsScreen() {
  const { t } = useTranslation();
  const [tick, setTick] = useState(0); // force refresh after edits

  // Profile values (MMKV sync)
  const quitDate = getString(StorageKeys.quitDate) ?? new Date().toISOString().slice(0, 10);
  const cigsPerDay = getNumber(StorageKeys.cigsPerDay) ?? 12;
  const pricePerPack = getNumber(StorageKeys.pricePerPack) ?? 12;
  const cigsPerPack = getNumber(StorageKeys.cigsPerPack) ?? 20;

  const isPremium = getBool(StorageKeys.isPremium) ?? false;

  // Notifications preference
  const notificationsEnabled = getBool(StorageKeys.notificationsEnabled) ?? true;

  const language = (getString(StorageKeys.language) as "fr" | "en" | null) ?? (i18n.language?.startsWith("fr") ? "fr" : "en");

  const refresh = () => setTick((x) => x + 1);

  const setLang = (lng: "fr" | "en") => {
    i18n.changeLanguage(lng);
    setString(StorageKeys.language, lng);
    refresh();
  };

  const toggleNotifications = async () => {
    const next = !notificationsEnabled;

    // optimistic update
    setBool(StorageKeys.notificationsEnabled, next);
    refresh();

    try {
      if (next) {
        const ok = await requestNotifPermissions();
        if (!ok) {
          setBool(StorageKeys.notificationsEnabled, false);
          refresh();
          Alert.alert(
            "Notifications",
            "Permission not granted. You can enable notifications in iOS Settings."
          );
          return;
        }
        await scheduleDailyMotivation(9, 0);
      } else {
        await cancelAllNotifications();
      }
    } catch (e) {
      // rollback on error
      setBool(StorageKeys.notificationsEnabled, !next);
      refresh();
      Alert.alert("Notifications", "Something went wrong. Please try again.");
    }
  };

  const startToday = () => {
    const today = new Date().toISOString().slice(0, 10);
    setString(StorageKeys.quitDate, today);
    refresh();
  };

  const bumpCigsPerDay = (delta: number) => {
    const next = Math.max(0, Math.min(80, cigsPerDay + delta));
    setNumber(StorageKeys.cigsPerDay, next);
    refresh();
  };

  const bumpPricePerPack = (delta: number) => {
    const next = Math.max(0, Math.min(50, pricePerPack + delta));
    setNumber(StorageKeys.pricePerPack, next);
    refresh();
  };

  const bumpCigsPerPack = (delta: number) => {
    const next = Math.max(1, Math.min(40, cigsPerPack + delta));
    setNumber(StorageKeys.cigsPerPack, next);
    refresh();
  };

  const restorePurchases = async () => {
    // Placeholder: RevenueCat restore à brancher ici
    Alert.alert(
      t("restore"),
      "Restore is not connected yet (RevenueCat)."
    );
  };

  const notifLabel = notificationsEnabled ? "Enabled" : "Disabled";

  return (
    <Screen>
      <Text style={styles.title}>{t("settings")}</Text>

      {/* Profile */}
      <View style={styles.block}>
        <Text style={styles.section}>Profile</Text>
        <Row label={t("quitDate")} value={quitDate} />
        <Row label={t("cigsPerDay")} value={`${cigsPerDay}`} />
        <Row label={t("pricePerPack")} value={`${pricePerPack} €`} />
        <Row label={t("cigsPerPack")} value={`${cigsPerPack}`} />

        <View style={styles.chipsRow}>
          <Chip title={t("startToday")} onPress={startToday} />
        </View>
      </View>

      {/* Quick edits */}
      <View style={styles.block}>
        <Text style={styles.section}>{t("editInputs")}</Text>
        <Text style={styles.hint}>Adjust quickly (MVP). You can replace with a full form later.</Text>

        <Text style={styles.subSection}>Cigarettes / day</Text>
        <View style={styles.chipsRow}>
          <Chip title="-1" onPress={() => bumpCigsPerDay(-1)} />
          <Chip title="+1" onPress={() => bumpCigsPerDay(1)} />
          <Chip title="+5" onPress={() => bumpCigsPerDay(5)} />
        </View>

        <Text style={styles.subSection}>Price / pack</Text>
        <View style={styles.chipsRow}>
          <Chip title="-1€" onPress={() => bumpPricePerPack(-1)} />
          <Chip title="+1€" onPress={() => bumpPricePerPack(1)} />
        </View>

        <Text style={styles.subSection}>Cigs / pack</Text>
        <View style={styles.chipsRow}>
          <Chip title="-1" onPress={() => bumpCigsPerPack(-1)} />
          <Chip title="+1" onPress={() => bumpCigsPerPack(1)} />
        </View>
      </View>

      {/* Notifications */}
      <View style={styles.block}>
        <Text style={styles.section}>Notifications</Text>
        <Row label="Daily motivation" value={notifLabel} />

        <View style={styles.chipsRow}>
          <Chip
            title={notificationsEnabled ? "Disable" : "Enable"}
            onPress={toggleNotifications}
            tone={notificationsEnabled ? "danger" : "primary"}
          />
        </View>

        <Text style={styles.hint}>
          Scheduled daily at 9:00. You can change this later.
        </Text>
      </View>

      {/* Language */}
      <View style={styles.block}>
        <Text style={styles.section}>{t("language")}</Text>
        <Row label="Current" value={language.toUpperCase()} />

        <View style={styles.chipsRow}>
          <Chip title="FR" onPress={() => setLang("fr")} tone={language === "fr" ? "primary" : "default"} />
          <Chip title="EN" onPress={() => setLang("en")} tone={language === "en" ? "primary" : "default"} />
        </View>
      </View>

      {/* Premium */}
      <View style={styles.block}>
        <Text style={styles.section}>{t("premium")}</Text>
        <Row label="Status" value={isPremium ? "Enabled" : "Free"} />

        <View style={styles.chipsRow}>
          <Chip title={t("restore")} onPress={restorePurchases} />
        </View>

        <Text style={styles.hint}>
          {Platform.OS === "ios"
            ? "Subscriptions are managed via Apple ID settings."
            : "Subscriptions are managed via your store account."}
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: {
    color: theme.colors.textPrimary,
    fontSize: theme.typography.h2.fontSize,
    fontWeight: "900",
    marginTop: theme.spacing.sm,
    marginBottom: theme.spacing.sm,
  },

  block: {
    marginTop: theme.spacing.md,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.radius.lg,
    padding: 16,
  },

  section: {
    color: theme.colors.textPrimary,
    fontWeight: "900",
    marginBottom: 8,
    fontSize: 16,
  },

  subSection: {
    color: theme.colors.textSecondary,
    marginTop: 12,
    marginBottom: 8,
    fontWeight: "800",
  },

  hint: {
    color: theme.colors.textTertiary,
    marginTop: 10,
    lineHeight: 18,
    fontSize: 12,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.divider,
  },
  rowLabel: { color: theme.colors.textSecondary },
  rowValue: { color: theme.colors.textPrimary, fontWeight: "700" },

  chipsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginTop: 12,
  },

  chip: {
    borderRadius: 999,
    borderWidth: 1,
    paddingVertical: 10,
    paddingHorizontal: 14,
    alignSelf: "flex-start",
  },
  chipText: { fontWeight: "900", fontSize: 13 },
});
