import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

// Important: comportement en foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export async function requestNotifPermissions(): Promise<boolean> {
  const settings = await Notifications.getPermissionsAsync();
  if (settings.granted || settings.ios?.status === Notifications.IosAuthorizationStatus.PROVISIONAL) {
    return true;
  }

  const req = await Notifications.requestPermissionsAsync({
    ios: {
      allowAlert: true,
      allowBadge: false,
      allowSound: false,
    },
  });

  return !!req.granted;
}

/**
 * Planifie une notification quotidienne (ex: 9h00).
 * On annule d'abord les anciennes pour éviter les doublons.
 */
export async function scheduleDailyMotivation(hour = 9, minute = 0): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "Keep going 💪",
      body: "Every smoke-free day is a win.",
    },
    trigger: {
      hour,
      minute,
      repeats: true,
    },
  });
}

/**
 * Exemples de milestones: 24h, 7j, 30j
 * Tu peux les appeler à la fin de l'onboarding si tu veux.
 */
export async function scheduleDefaultMilestones(): Promise<void> {
  // 24h
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "24 hours 🎉",
      body: "First big step. Keep going.",
    },
    trigger: { seconds: 24 * 60 * 60 },
  });

  // 7 jours
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "7 days 💚",
      body: "A full week. You’re building momentum.",
    },
    trigger: { seconds: 7 * 24 * 60 * 60 },
  });

  // 30 jours
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "30 days 🚀",
      body: "One month. That’s huge.",
    },
    trigger: { seconds: 30 * 24 * 60 * 60 },
  });
}

export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
